main(){printf("EEL270 - Computacao II - Turma 2023/1 - Primeiro Exemplo");}
