/*******************************************************************************
 *
 * Universidade Federal do Rio de Janeiro
 * Escola Politecnica
 * Departamento de Eletronica e de Computacao
 * Prof. Marcelo Luiz Drumond Lanza
 * EEL270 - Computacao II - Turma 2023/1
 *
 * Descricao:
 *
 * $Author: marcelo.lanza $
 * $Date: 2023/04/10 13:50:36 $
 * $Log: exemplo_002.c,v $
 * Revision 1.1  2023/04/10 13:50:36  marcelo.lanza
 * Initial revision
 *
 *
 *******************************************************************************/

main () 
{
	printf ("EEL270 - Computacao II - Turma 2023/1 - Segundo Exemplo");
}

/* $RCSfile: exemplo_002.c,v $ */
